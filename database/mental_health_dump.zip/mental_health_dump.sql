-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: localhost    Database: mental_health
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `mental_health`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `mental_health` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `mental_health`;

--
-- Table structure for table `answers`
--

DROP TABLE IF EXISTS `answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `question_id` int DEFAULT NULL,
  `answer_value` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_answer_user` (`user_id`),
  KEY `fk_answer_question` (`question_id`),
  CONSTRAINT `fk_answer_question` FOREIGN KEY (`question_id`) REFERENCES `questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_answer_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answers`
--

LOCK TABLES `answers` WRITE;
/*!40000 ALTER TABLE `answers` DISABLE KEYS */;
/*!40000 ALTER TABLE `answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(255) NOT NULL,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES ('assessment_time_limit_minutes','20','2026-07-18 04:34:38');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `articles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `admin_id` int NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `content` text COLLATE utf8mb4_general_ci NOT NULL,
  `category` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tags` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `published_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_articles_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articles`
--

LOCK TABLES `articles` WRITE;
/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` VALUES (13,0,'Menjaga Kesehatan Mental Mahasiswa','Kesehatan mental sangat penting bagi mahasiswa. Mengelola stres, menjaga pola tidur, dan berbagi cerita adalah langkah awal menjaga keseimbangan emosi.','Edukasi',NULL,NULL,'2026-02-04 14:48:55','2026-02-04 14:48:55',0),(14,0,'Cara Mengatasi Stres Akademik','Stres akademik dapat dikurangi dengan manajemen waktu yang baik, menetapkan prioritas, dan meminta bantuan saat dibutuhkan.','Tips',NULL,NULL,'2026-02-04 14:48:55','2026-02-04 14:48:55',0),(15,0,'Pentingnya Self-Assessment Kesehatan Mental','Self-assessment membantu mahasiswa mengenali kondisi emosional sejak dini sehingga dapat mengambil langkah pencegahan.','Assessment',NULL,NULL,'2026-02-04 14:48:55','2026-02-04 14:48:55',0),(18,25,'ARTIKEL','Artikelsdalsdksmldsmalkdasdasdsdmsldsm','Edukasi','/uploads/articles/b220bf342553857a556f2b5a9f481d1e.webp','edukasi, psikologi','2026-07-15 08:34:04','2026-07-15 08:34:04',25),(19,25,'TESSTST','Test Artikel','Tips','/uploads/articles/23a8b3f05d6f393008f09574e46e8d7d.webp','stress, kuliah, mahasiswa','2026-07-15 08:36:24','2026-07-15 08:36:24',25),(21,3,'ARTIKEL BARU EDIT','Isi artikel','Edukasi','/uploads/articles/f43363af8520cf584774297e8ef39ad0.webp','kuliah, psikologi','2026-07-15 09:22:20','2026-07-15 09:22:20',3);
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_answers`
--

DROP TABLE IF EXISTS `assessment_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_answers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `submission_id` int unsigned NOT NULL,
  `question_id` int unsigned NOT NULL,
  `choice_id` int unsigned NOT NULL,
  `score_value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `question_id` (`question_id`),
  KEY `choice_id` (`choice_id`),
  KEY `idx_submission` (`submission_id`),
  CONSTRAINT `assessment_answers_ibfk_1` FOREIGN KEY (`submission_id`) REFERENCES `assessment_submissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assessment_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `assessment_questions` (`id`),
  CONSTRAINT `assessment_answers_ibfk_3` FOREIGN KEY (`choice_id`) REFERENCES `assessment_choices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=334 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_answers`
--

LOCK TABLES `assessment_answers` WRITE;
/*!40000 ALTER TABLE `assessment_answers` DISABLE KEYS */;
INSERT INTO `assessment_answers` VALUES (178,12,1,4,3),(179,12,2,8,3),(180,12,3,12,3),(181,12,4,16,3),(182,12,5,20,3),(183,12,6,24,3),(184,12,7,28,3),(185,12,8,32,3),(186,12,9,36,3),(187,12,10,40,3),(188,12,11,44,3),(189,12,12,48,3),(190,12,13,52,3),(191,12,14,56,3),(192,12,15,60,3),(193,12,16,66,3),(194,12,17,71,3),(195,12,18,77,3),(196,12,19,82,3),(197,12,20,86,3),(198,12,21,90,3),(199,13,22,96,6),(200,13,23,97,1),(201,13,24,108,1),(202,13,25,114,1),(203,13,26,120,1),(204,13,27,121,1),(205,13,28,127,1),(206,13,29,133,1),(207,13,30,144,1),(208,13,31,150,1),(209,13,32,151,1),(210,13,33,157,1),(211,13,34,168,1),(212,13,35,169,1),(213,13,36,175,1),(214,13,37,186,1),(215,13,38,192,1),(216,13,39,193,1),(217,14,1,3,2),(218,14,2,6,1),(219,14,3,11,2),(220,14,4,14,1),(221,14,5,19,2),(222,14,6,22,1),(223,14,7,27,2),(224,14,8,30,1),(225,14,9,35,2),(226,14,10,38,1),(227,14,11,43,2),(228,14,12,46,1),(229,14,13,51,2),(230,14,14,54,1),(231,14,15,59,2),(232,14,16,64,2),(233,14,17,69,1),(234,14,18,74,1),(235,14,19,81,2),(236,14,20,85,2),(237,14,21,88,1),(238,15,22,94,4),(239,15,23,100,4),(240,15,24,106,3),(241,15,25,111,4),(242,15,26,116,5),(243,15,27,125,5),(244,15,28,131,5),(245,15,29,137,5),(246,15,30,142,3),(247,15,31,146,5),(248,15,32,153,3),(249,15,33,160,4),(250,15,34,165,4),(251,15,35,172,4),(252,15,36,177,3),(253,15,37,184,3),(254,15,38,190,3),(255,15,39,195,3),(256,16,1,1,0),(257,16,2,5,0),(258,16,3,9,0),(259,16,4,13,0),(260,16,5,17,0),(261,16,6,21,0),(262,16,7,25,0),(263,16,8,29,0),(264,16,9,33,0),(265,16,10,37,0),(266,16,11,41,0),(267,16,12,45,0),(268,16,13,49,0),(269,16,14,53,0),(270,16,15,57,0),(271,16,16,61,0),(272,16,17,68,0),(273,16,18,72,0),(274,16,19,79,0),(275,16,20,83,0),(276,16,21,87,0),(277,17,22,95,5),(278,17,23,101,5),(279,17,24,104,5),(280,17,25,111,4),(281,17,26,116,5),(282,17,27,126,6),(283,17,28,131,5),(284,17,29,136,4),(285,17,30,142,3),(286,17,31,146,5),(287,17,32,155,5),(288,17,33,161,5),(289,17,34,166,3),(290,17,35,172,4),(291,17,36,179,5),(292,17,37,183,4),(293,17,38,188,5),(294,17,39,197,5),(295,18,1,3,2),(296,18,2,7,2),(297,18,3,11,2),(298,18,4,15,2),(299,18,5,19,2),(300,18,6,23,2),(301,18,7,27,2),(302,18,8,31,2),(303,18,9,35,2),(304,18,10,39,2),(305,18,11,43,2),(306,18,12,47,2),(307,18,13,51,2),(308,18,14,55,2),(309,18,15,59,2),(310,18,16,66,3),(311,18,17,70,2),(312,18,18,76,2),(313,18,19,81,2),(314,18,20,85,2),(315,18,21,89,2),(316,19,22,94,4),(317,19,23,100,4),(318,19,24,107,2),(319,19,25,111,4),(320,19,26,116,5),(321,19,27,124,4),(322,19,28,130,4),(323,19,29,136,4),(324,19,30,141,4),(325,19,31,147,4),(326,19,32,154,4),(327,19,33,160,4),(328,19,34,165,4),(329,19,35,171,3),(330,19,36,177,3),(331,19,37,184,3),(332,19,38,189,4),(333,19,39,196,4);
/*!40000 ALTER TABLE `assessment_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_choices`
--

DROP TABLE IF EXISTS `assessment_choices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_choices` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `question_id` int unsigned NOT NULL,
  `order_no` int unsigned NOT NULL,
  `label` varchar(255) NOT NULL,
  `score_value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_question_order` (`question_id`,`order_no`),
  CONSTRAINT `assessment_choices_ibfk_1` FOREIGN KEY (`question_id`) REFERENCES `assessment_questions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=199 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_choices`
--

LOCK TABLES `assessment_choices` WRITE;
/*!40000 ALTER TABLE `assessment_choices` DISABLE KEYS */;
INSERT INTO `assessment_choices` VALUES (1,1,0,'Saya tidak merasa sedih.',0),(2,1,1,'Saya sering kali merasa sedih.',1),(3,1,2,'Saya merasa sedih sepanjang waktu.',2),(4,1,3,'Saya merasa sangat tidak bahagia atau sedih sampai tidak tertahankan.',3),(5,2,0,'Saya tidak meragukan masa depan saya.',0),(6,2,1,'Saya merasa lebih meragukan masa depan saya dibanding biasanya.',1),(7,2,2,'Saya merasa segala sesuatu tidak berjalan dengan baik bagi saya.',2),(8,2,3,'Saya merasa masa depan saya tidak ada harapan dan akan semakin buruk.',3),(9,3,0,'Saya tidak merasa gagal.',0),(10,3,1,'Saya telah gagal lebih dari yang seharusnya.',1),(11,3,2,'Saya melakukan banyak kegagalan di masa lalu.',2),(12,3,3,'Saya merasa gagal sama sekali (betul-betul gagal).',3),(13,4,0,'Saya mendapatkan kesenangan dari hal-hal yang saya lakukan.',0),(14,4,1,'Saya tidak menikmati sesuatu seperti biasanya.',1),(15,4,2,'Saya hanya mendapatkan sangat sedikit kesenangan dari hal-hal yang biasanya bisa saya nikmati.',2),(16,4,3,'Saya tidak mendapatkan kesenangan sama sekali dari hal-hal yang biasanya bisa saya nikmati.',3),(17,5,0,'Saya sama sekali tidak merasa bersalah.',0),(18,5,1,'Saya merasa bersalah atas banyak hal yang telah atau seharusnya saya lakukan.',1),(19,5,2,'Saya sering merasa bersalah.',2),(20,5,3,'Saya merasa bersalah setiap saat.',3),(21,6,0,'Saya tidak merasa bahwa saya sedang dihukum.',0),(22,6,1,'Saya merasa bahwa mungkin saya akan dihukum.',1),(23,6,2,'Saya yakin bahwa saya akan dihukum.',2),(24,6,3,'Saya merasa bahwa saya sedang dihukum.',3),(25,7,0,'Saya tidak merasa kecewa pada diri sendiri.',0),(26,7,1,'Saya kehilangan kepercayaan pada diri sendiri.',1),(27,7,2,'Saya merasa kecewa pada diri sendiri.',2),(28,7,3,'Saya benci pada diri sendiri.',3),(29,8,0,'Saya tidak mengkritik atau menyalahkan diri sendiri lebih dari biasanya.',0),(30,8,1,'Saya mengkritik diri sendiri lebih dari biasanya.',1),(31,8,2,'Saya mengkritik diri sendiri atas semua kesalahan yang saya lakukan.',2),(32,8,3,'Saya menyalahkan diri sendiri untuk semua hal-hal buruk yang terjadi.',3),(33,9,0,'Saya tidak berpikir untuk bunuh diri.',0),(34,9,1,'Saya berpikir untuk bunuh diri, tetapi hal itu tidak akan saya lakukan.',1),(35,9,2,'Saya ingin bunuh diri.',2),(36,9,3,'Saya akan bunuh diri seandainya ada kesempatan.',3),(37,10,0,'Saya tidak menangis lagi seperti biasanya.',0),(38,10,1,'Saya lebih sering menangis dibanding biasanya.',1),(39,10,2,'Saya menangis bahkan untuk masalah masalah kecil.',2),(40,10,3,'Rasanya saya ingin sekali menangis tetapi tidak bisa.',3),(41,11,0,'Saya tidak lagi merasa gelisah atau tertekan dibandingkan biasanya.',0),(42,11,1,'Saya merasa lebih mudah gelisah atau tertekan dibanding biasanya.',1),(43,11,2,'Saya sangat tertekan dan gelisah sampai sulit untuk berdiam diri.',2),(44,11,3,'Saya sangat gelisah sehingga harus senantiasa bergerak atau melakukan sesuatu.',3),(45,12,0,'Saya tidak kehilangan minat untuk berelasi dengan orang lain atau melakukan aktivitas.',0),(46,12,1,'Saya kurang berminat untuk berelasi dengan orang lain atau terhadap sesuatu dibandingkan biasanya.',1),(47,12,2,'Saya kehilangan hampir seluruh minat saya untuk berelasi dengan orang lain atau terhadap sesuatu.',2),(48,12,3,'Saya tidak berminat akan apapun.',3),(49,13,0,'Saya dapat mengambil keputusan sebagaimana yang biasanya saya lakukan.',0),(50,13,1,'Saya agak sulit mengambil keputusan dibanding biasanya.',1),(51,13,2,'Saya lebih banyak mengalami kesulitan dalam mengambil keputusan dibanding biasanya.',2),(52,13,3,'Saya sangat mengalami kesulitan setiap kali mengambil keputusan.',3),(53,14,0,'Saya merasa layak.',0),(54,14,1,'Saya merasa tidak layak dan tidak berguna dibandingkan biasanya.',1),(55,14,2,'Saya merasa lebih tidak layak dibanding orang lain.',2),(56,14,3,'Saya merasa sama sekali tidak layak.',3),(57,15,0,'Saya memiliki tenaga (semangat) seperti biasanya.',0),(58,15,1,'Saya memiliki tenaga lebih sedikit dibanding yang seharusnya saya miliki.',1),(59,15,2,'Saya tidak memiliki tenaga yang cukup untuk berbuat banyak.',2),(60,15,3,'Saya tidak memiliki tenaga yang cukup untuk melakukan apapun.',3),(61,16,0,'Saya tidak mengalami perubahan apapun dalam pola tidur saya.',0),(62,16,1,'Saya tidur lebih dari biasanya.',1),(63,16,2,'Saya tidur kurang dari biasanya.',1),(64,16,3,'Saya tidur jauh lebih lama dari biasanya.',2),(65,16,4,'Saya tidur sangat kurang dari biasanya.',2),(66,16,5,'Saya tidur hampir sepanjang hari.',3),(67,16,6,'Saya bangun 1-2 jam lebih awal dan tidak dapat tidur kembali.',3),(68,17,0,'Saya tidak lebih mudah marah seperti biasanya.',0),(69,17,1,'Saya lebih mudah marah dibanding biasanya.',1),(70,17,2,'Saya jauh lebih mudah marah dibanding biasanya.',2),(71,17,3,'Saya mudah marah sepanjang waktu.',3),(72,18,0,'Selera makan saya tidak berubah (tidak lebih buruk) dari biasanya.',0),(73,18,1,'Selera makan saya kurang dari biasanya.',1),(74,18,2,'Selera makan saya lebih dari biasanya.',1),(75,18,3,'Selera makan saya sangat kurang dibanding biasanya.',2),(76,18,4,'Selera makan saya sangat lebih dibanding biasanya.',2),(77,18,5,'Saya tidak punya selera makan sama sekali.',3),(78,18,6,'Saya ingin makan setiap waktu.',3),(79,19,0,'Saya mampu berkonsentrasi seperti biasanya.',0),(80,19,1,'Saya tidak mampu berkonsentrasi seperti biasanya.',1),(81,19,2,'Saya sangat sulit untuk tetap memusatkan pikiran terhadap sesuatu dalam jangka waktu yang panjang.',2),(82,19,3,'Saya merasa saya tidak mampu berkonsentrasi dalam semua hal.',3),(83,20,0,'Saya tidak lebih capek atau lelah dibanding biasanya.',0),(84,20,1,'Saya lebih mudah capek atau lelah dari biasanya.',1),(85,20,2,'Saya merasa capek atau lelah untuk melakukan banyak hal yang biasanya saya lakukan.',2),(86,20,3,'Saya terlalu capek atau lelah untuk melakukan hampir semua hal yang biasanya saya lakukan.',3),(87,21,0,'Saya tidak melihat adanya perubahan pada gairah seksual saya.',0),(88,21,1,'Gairah seksual saya berkurang, tidak seperti biasanya.',1),(89,21,2,'Saya menjadi sangat kurang berminat pada aktivitas seksual saat ini.',2),(90,21,3,'Gairah seksual saya hilang sama sekali.',3),(91,22,1,'Sangat Tidak Setuju (STS)',1),(92,22,2,'Tidak Setuju (TS)',2),(93,22,3,'Agak Tidak Setuju (ATS)',3),(94,22,4,'Agak Setuju (AS)',4),(95,22,5,'Setuju (S)',5),(96,22,6,'Sangat Setuju (SS)',6),(97,23,1,'Sangat Tidak Setuju (STS)',1),(98,23,2,'Tidak Setuju (TS)',2),(99,23,3,'Agak Tidak Setuju (ATS)',3),(100,23,4,'Agak Setuju (AS)',4),(101,23,5,'Setuju (S)',5),(102,23,6,'Sangat Setuju (SS)',6),(103,24,1,'Sangat Tidak Setuju (STS)',1),(104,24,2,'Tidak Setuju (TS)',2),(105,24,3,'Agak Tidak Setuju (ATS)',3),(106,24,4,'Agak Setuju (AS)',4),(107,24,5,'Setuju (S)',5),(108,24,6,'Sangat Setuju (SS)',6),(109,25,1,'Sangat Tidak Setuju (STS)',1),(110,25,2,'Tidak Setuju (TS)',2),(111,25,3,'Agak Tidak Setuju (ATS)',3),(112,25,4,'Agak Setuju (AS)',4),(113,25,5,'Setuju (S)',5),(114,25,6,'Sangat Setuju (SS)',6),(115,26,1,'Sangat Tidak Setuju (STS)',1),(116,26,2,'Tidak Setuju (TS)',2),(117,26,3,'Agak Tidak Setuju (ATS)',3),(118,26,4,'Agak Setuju (AS)',4),(119,26,5,'Setuju (S)',5),(120,26,6,'Sangat Setuju (SS)',6),(121,27,1,'Sangat Tidak Setuju (STS)',1),(122,27,2,'Tidak Setuju (TS)',2),(123,27,3,'Agak Tidak Setuju (ATS)',3),(124,27,4,'Agak Setuju (AS)',4),(125,27,5,'Setuju (S)',5),(126,27,6,'Sangat Setuju (SS)',6),(127,28,1,'Sangat Tidak Setuju (STS)',1),(128,28,2,'Tidak Setuju (TS)',2),(129,28,3,'Agak Tidak Setuju (ATS)',3),(130,28,4,'Agak Setuju (AS)',4),(131,28,5,'Setuju (S)',5),(132,28,6,'Sangat Setuju (SS)',6),(133,29,1,'Sangat Tidak Setuju (STS)',1),(134,29,2,'Tidak Setuju (TS)',2),(135,29,3,'Agak Tidak Setuju (ATS)',3),(136,29,4,'Agak Setuju (AS)',4),(137,29,5,'Setuju (S)',5),(138,29,6,'Sangat Setuju (SS)',6),(139,30,1,'Sangat Tidak Setuju (STS)',1),(140,30,2,'Tidak Setuju (TS)',2),(141,30,3,'Agak Tidak Setuju (ATS)',3),(142,30,4,'Agak Setuju (AS)',4),(143,30,5,'Setuju (S)',5),(144,30,6,'Sangat Setuju (SS)',6),(145,31,1,'Sangat Tidak Setuju (STS)',1),(146,31,2,'Tidak Setuju (TS)',2),(147,31,3,'Agak Tidak Setuju (ATS)',3),(148,31,4,'Agak Setuju (AS)',4),(149,31,5,'Setuju (S)',5),(150,31,6,'Sangat Setuju (SS)',6),(151,32,1,'Sangat Tidak Setuju (STS)',1),(152,32,2,'Tidak Setuju (TS)',2),(153,32,3,'Agak Tidak Setuju (ATS)',3),(154,32,4,'Agak Setuju (AS)',4),(155,32,5,'Setuju (S)',5),(156,32,6,'Sangat Setuju (SS)',6),(157,33,1,'Sangat Tidak Setuju (STS)',1),(158,33,2,'Tidak Setuju (TS)',2),(159,33,3,'Agak Tidak Setuju (ATS)',3),(160,33,4,'Agak Setuju (AS)',4),(161,33,5,'Setuju (S)',5),(162,33,6,'Sangat Setuju (SS)',6),(163,34,1,'Sangat Tidak Setuju (STS)',1),(164,34,2,'Tidak Setuju (TS)',2),(165,34,3,'Agak Tidak Setuju (ATS)',3),(166,34,4,'Agak Setuju (AS)',4),(167,34,5,'Setuju (S)',5),(168,34,6,'Sangat Setuju (SS)',6),(169,35,1,'Sangat Tidak Setuju (STS)',1),(170,35,2,'Tidak Setuju (TS)',2),(171,35,3,'Agak Tidak Setuju (ATS)',3),(172,35,4,'Agak Setuju (AS)',4),(173,35,5,'Setuju (S)',5),(174,35,6,'Sangat Setuju (SS)',6),(175,36,1,'Sangat Tidak Setuju (STS)',1),(176,36,2,'Tidak Setuju (TS)',2),(177,36,3,'Agak Tidak Setuju (ATS)',3),(178,36,4,'Agak Setuju (AS)',4),(179,36,5,'Setuju (S)',5),(180,36,6,'Sangat Setuju (SS)',6),(181,37,1,'Sangat Tidak Setuju (STS)',1),(182,37,2,'Tidak Setuju (TS)',2),(183,37,3,'Agak Tidak Setuju (ATS)',3),(184,37,4,'Agak Setuju (AS)',4),(185,37,5,'Setuju (S)',5),(186,37,6,'Sangat Setuju (SS)',6),(187,38,1,'Sangat Tidak Setuju (STS)',1),(188,38,2,'Tidak Setuju (TS)',2),(189,38,3,'Agak Tidak Setuju (ATS)',3),(190,38,4,'Agak Setuju (AS)',4),(191,38,5,'Setuju (S)',5),(192,38,6,'Sangat Setuju (SS)',6),(193,39,1,'Sangat Tidak Setuju (STS)',1),(194,39,2,'Tidak Setuju (TS)',2),(195,39,3,'Agak Tidak Setuju (ATS)',3),(196,39,4,'Agak Setuju (AS)',4),(197,39,5,'Setuju (S)',5),(198,39,6,'Sangat Setuju (SS)',6);
/*!40000 ALTER TABLE `assessment_choices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_questions`
--

DROP TABLE IF EXISTS `assessment_questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_questions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('bdi2','pwb') NOT NULL,
  `order_no` int unsigned NOT NULL,
  `question_text` varchar(500) NOT NULL,
  `dimension` varchar(50) DEFAULT NULL,
  `is_reverse_scored` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_type_order` (`type`,`order_no`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_questions`
--

LOCK TABLES `assessment_questions` WRITE;
/*!40000 ALTER TABLE `assessment_questions` DISABLE KEYS */;
INSERT INTO `assessment_questions` VALUES (1,'bdi2',1,'Kesedihan',NULL,0,'2026-07-17 09:22:25'),(2,'bdi2',2,'Pesimis',NULL,0,'2026-07-17 09:22:25'),(3,'bdi2',3,'Kegagalan masa lalu',NULL,0,'2026-07-17 09:22:25'),(4,'bdi2',4,'Kehilangan gairah',NULL,0,'2026-07-17 09:22:25'),(5,'bdi2',5,'Perasaan bersalah',NULL,0,'2026-07-17 09:22:25'),(6,'bdi2',6,'Perasaan dihukum',NULL,0,'2026-07-17 09:22:25'),(7,'bdi2',7,'Tidak menyukai diri sendiri',NULL,0,'2026-07-17 09:22:25'),(8,'bdi2',8,'Mengkritik diri sendiri',NULL,0,'2026-07-17 09:22:25'),(9,'bdi2',9,'Pikiran-pikiran atau keinginan bunuh diri',NULL,0,'2026-07-17 09:22:25'),(10,'bdi2',10,'Menangis',NULL,0,'2026-07-17 09:22:25'),(11,'bdi2',11,'Gelisah',NULL,0,'2026-07-17 09:22:25'),(12,'bdi2',12,'Kehilangan minat',NULL,0,'2026-07-17 09:22:25'),(13,'bdi2',13,'Sulit mengambil keputusan',NULL,0,'2026-07-17 09:22:25'),(14,'bdi2',14,'Merasa tidak layak',NULL,0,'2026-07-17 09:22:25'),(15,'bdi2',15,'Kehilangan tenaga (semangat)',NULL,0,'2026-07-17 09:22:25'),(16,'bdi2',16,'Perubahan pola tidur',NULL,0,'2026-07-17 09:22:25'),(17,'bdi2',17,'Mudah marah',NULL,0,'2026-07-17 09:22:25'),(18,'bdi2',18,'Perubahan selera makan',NULL,0,'2026-07-17 09:22:25'),(19,'bdi2',19,'Sulit berkonsentrasi',NULL,0,'2026-07-17 09:22:25'),(20,'bdi2',20,'Capek atau Kelelahan',NULL,0,'2026-07-17 09:22:25'),(21,'bdi2',21,'Kehilangan gairah seksual',NULL,0,'2026-07-17 09:22:25'),(22,'pwb',1,'Secara umum, saya merasa bertanggung jawab atas situasi lingkungan tempat saya tinggal','environmental_mastery',0,'2026-07-17 09:22:25'),(23,'pwb',2,'Ketika mengingat perjalanan hidup saya sendiri, senang rasanya melihat beberapa hal telah berubah.','self_acceptance',0,'2026-07-17 09:22:25'),(24,'pwb',3,'Menjaga hubungan dekat dengan orang lain adalah hal yang sulit bagi saya.','positive_relations',1,'2026-07-17 09:22:25'),(25,'pwb',4,'Tuntutan kehidupan sehari-hari sering membuat saya tertekan.','environmental_mastery',1,'2026-07-17 09:22:25'),(26,'pwb',5,'Saya menjalani hidup hanya untuk hari ini dan tidak terlalu memikirkan masa depan.','purpose_in_life',1,'2026-07-17 09:22:25'),(27,'pwb',6,'Saya cukup pandai mengelola banyak tanggung jawab kehidupan sehari-hari','environmental_mastery',0,'2026-07-17 09:22:25'),(28,'pwb',7,'Penting untuk memiliki pengalaman baru yang membuat saya dapat berpikir tentang diri sendiri dan dunia','personal_growth',0,'2026-07-17 09:22:25'),(29,'pwb',8,'Saya suka sebagian besar hal-hal yang ada dalam kepribadian saya','self_acceptance',0,'2026-07-17 09:22:25'),(30,'pwb',9,'Saya cenderung terpengaruh oleh orang-orang dengan pendapat yang kuat','autonomy',1,'2026-07-17 09:22:25'),(31,'pwb',10,'Dalam banyak hal, saya merasa kecewa dengan pencapaian hidup','self_acceptance',1,'2026-07-17 09:22:25'),(32,'pwb',11,'Orang-orang akan menggambarkan saya sebagai orang yang suka memberi dan senang berbagi waktu dengan orang lain','positive_relations',0,'2026-07-17 09:22:25'),(33,'pwb',12,'Saya yakin pada pendapat sendiri, bahkan jika hal itu bertentangan dengan pendapat umum','autonomy',0,'2026-07-17 09:22:25'),(34,'pwb',13,'Saya tidak memiliki banyak hubungan yang hangat dan saling percaya dengan orang lain','positive_relations',1,'2026-07-17 09:22:25'),(35,'pwb',14,'Beberapa orang tidak memiliki tujuan hidup, tapi saya bukan salah satu dari mereka','purpose_in_life',0,'2026-07-17 09:22:25'),(36,'pwb',15,'Bagi saya, hidup adalah proses belajar, berubah, dan berkembang terus menerus','personal_growth',0,'2026-07-17 09:22:25'),(37,'pwb',16,'Saya terkadang merasa seolah-olah semua usaha dalam hidup ini sudah dilakukan','purpose_in_life',1,'2026-07-17 09:22:25'),(38,'pwb',17,'Saya menyerah dalam usaha untuk melakukan perbaikan besar atau perubahan dalam hidup','personal_growth',1,'2026-07-17 09:22:25'),(39,'pwb',18,'Saya menilai diri sendiri berdasarkan apa yang saya anggap penting secara pribadi, bukan oleh nilai-nilai yang dianggap penting oleh orang lain','autonomy',0,'2026-07-17 09:22:25');
/*!40000 ALTER TABLE `assessment_questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_results`
--

DROP TABLE IF EXISTS `assessment_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_results` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `username` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `result_summary` text COLLATE utf8mb4_general_ci,
  `assessment_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tanggal_tes` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `total_skor` int NOT NULL,
  `kesimpulan` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `saran_tindakan` text COLLATE utf8mb4_general_ci,
  `status_review` enum('Belum Dilihat','Sudah Direview') COLLATE utf8mb4_general_ci DEFAULT 'Belum Dilihat',
  PRIMARY KEY (`id`),
  KEY `fk_assessment_user` (`user_id`),
  CONSTRAINT `fk_assessment_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_results`
--

LOCK TABLES `assessment_results` WRITE;
/*!40000 ALTER TABLE `assessment_results` DISABLE KEYS */;
/*!40000 ALTER TABLE `assessment_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_session_answers`
--

DROP TABLE IF EXISTS `assessment_session_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_session_answers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `session_id` int unsigned NOT NULL,
  `question_id` int unsigned NOT NULL,
  `choice_id` int unsigned NOT NULL,
  `score_value` int NOT NULL,
  `answered_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_session_question` (`session_id`,`question_id`),
  KEY `question_id` (`question_id`),
  KEY `choice_id` (`choice_id`),
  CONSTRAINT `assessment_session_answers_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `assessment_sessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assessment_session_answers_ibfk_2` FOREIGN KEY (`question_id`) REFERENCES `assessment_questions` (`id`),
  CONSTRAINT `assessment_session_answers_ibfk_3` FOREIGN KEY (`choice_id`) REFERENCES `assessment_choices` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=252 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_session_answers`
--

LOCK TABLES `assessment_session_answers` WRITE;
/*!40000 ALTER TABLE `assessment_session_answers` DISABLE KEYS */;
INSERT INTO `assessment_session_answers` VALUES (82,4,1,4,3,'2026-07-17 16:48:48'),(83,4,3,12,3,'2026-07-17 16:48:51'),(84,4,2,8,3,'2026-07-17 16:48:53'),(85,4,4,16,3,'2026-07-17 16:48:55'),(86,4,5,20,3,'2026-07-17 16:48:57'),(87,4,6,24,3,'2026-07-17 16:48:59'),(88,4,7,28,3,'2026-07-17 16:49:01'),(89,4,8,32,3,'2026-07-17 16:49:02'),(90,4,9,36,3,'2026-07-17 16:49:04'),(91,4,10,40,3,'2026-07-17 16:49:05'),(92,4,11,44,3,'2026-07-17 16:49:07'),(93,4,12,48,3,'2026-07-17 16:49:08'),(94,4,13,52,3,'2026-07-17 16:49:09'),(95,4,14,56,3,'2026-07-17 16:49:10'),(96,4,15,60,3,'2026-07-17 16:49:12'),(97,4,16,66,3,'2026-07-17 16:49:16'),(99,4,17,71,3,'2026-07-17 16:49:19'),(100,4,18,77,3,'2026-07-17 16:49:22'),(101,4,19,82,3,'2026-07-17 16:49:26'),(102,4,20,86,3,'2026-07-17 16:49:28'),(103,4,21,90,3,'2026-07-17 16:49:30'),(104,4,22,96,6,'2026-07-17 16:49:38'),(105,4,23,97,1,'2026-07-17 16:49:42'),(106,4,24,108,6,'2026-07-17 16:49:47'),(107,4,25,114,6,'2026-07-17 16:49:50'),(108,4,26,120,6,'2026-07-17 16:49:54'),(109,4,27,121,1,'2026-07-17 16:49:57'),(110,4,28,127,1,'2026-07-17 16:50:04'),(111,4,29,133,1,'2026-07-17 16:50:08'),(112,4,30,144,6,'2026-07-17 16:50:13'),(113,4,31,150,6,'2026-07-17 16:50:16'),(114,4,32,151,1,'2026-07-17 16:50:20'),(115,4,33,157,1,'2026-07-17 16:50:23'),(116,4,34,168,6,'2026-07-17 16:50:27'),(118,4,35,169,1,'2026-07-17 16:50:31'),(119,4,36,175,1,'2026-07-17 16:50:33'),(120,4,37,186,6,'2026-07-17 16:50:38'),(121,4,38,192,6,'2026-07-17 16:50:42'),(122,4,39,193,1,'2026-07-17 16:50:51'),(123,5,1,3,2,'2026-07-17 17:25:57'),(124,5,2,6,1,'2026-07-17 17:25:58'),(125,5,3,11,2,'2026-07-17 17:26:00'),(126,5,4,14,1,'2026-07-17 17:26:01'),(127,5,5,19,2,'2026-07-17 17:26:04'),(128,5,6,22,1,'2026-07-17 17:26:05'),(129,5,7,27,2,'2026-07-17 17:26:07'),(130,5,8,30,1,'2026-07-17 17:26:09'),(131,5,9,35,2,'2026-07-17 17:26:11'),(132,5,10,38,1,'2026-07-17 17:26:12'),(133,5,11,43,2,'2026-07-17 17:26:14'),(134,5,12,46,1,'2026-07-17 17:26:16'),(135,5,13,51,2,'2026-07-17 17:26:17'),(136,5,14,54,1,'2026-07-17 17:26:19'),(137,5,15,59,2,'2026-07-17 17:26:20'),(138,5,16,64,2,'2026-07-17 17:26:24'),(139,5,17,69,1,'2026-07-17 17:26:27'),(140,5,18,74,1,'2026-07-17 17:26:33'),(141,5,19,81,2,'2026-07-17 17:26:44'),(144,5,20,85,2,'2026-07-17 17:26:49'),(147,5,21,88,1,'2026-07-17 17:26:52'),(148,5,22,94,4,'2026-07-17 17:26:57'),(149,5,23,100,4,'2026-07-17 17:27:04'),(150,5,24,106,4,'2026-07-17 17:27:06'),(151,5,25,111,3,'2026-07-17 17:27:08'),(152,5,26,116,2,'2026-07-17 17:27:14'),(153,5,27,125,5,'2026-07-17 17:27:17'),(154,5,28,131,5,'2026-07-17 17:27:20'),(155,5,29,137,5,'2026-07-17 17:27:24'),(156,5,30,142,4,'2026-07-17 17:27:27'),(157,5,31,146,2,'2026-07-17 17:27:30'),(158,5,32,153,3,'2026-07-17 17:27:35'),(159,5,33,160,4,'2026-07-17 17:27:40'),(160,5,34,165,3,'2026-07-17 17:27:43'),(161,5,35,172,4,'2026-07-17 17:27:51'),(164,5,36,177,3,'2026-07-17 17:27:52'),(165,5,37,184,4,'2026-07-17 17:27:54'),(166,5,38,190,4,'2026-07-17 17:27:59'),(167,5,39,195,3,'2026-07-17 17:28:01'),(168,6,1,1,0,'2026-07-17 17:29:03'),(169,6,2,5,0,'2026-07-17 17:29:02'),(170,6,3,9,0,'2026-07-17 17:29:00'),(174,6,4,13,0,'2026-07-17 17:29:08'),(175,6,5,17,0,'2026-07-17 17:29:10'),(176,6,6,21,0,'2026-07-17 17:29:12'),(177,6,7,25,0,'2026-07-17 17:29:14'),(178,6,8,29,0,'2026-07-17 17:29:15'),(179,6,9,33,0,'2026-07-17 17:29:17'),(180,6,10,37,0,'2026-07-17 17:29:18'),(181,6,11,41,0,'2026-07-17 17:29:20'),(182,6,12,45,0,'2026-07-17 17:29:21'),(183,6,13,49,0,'2026-07-17 17:29:23'),(184,6,14,53,0,'2026-07-17 17:29:24'),(185,6,15,57,0,'2026-07-17 17:29:26'),(186,6,16,61,0,'2026-07-17 17:29:27'),(187,6,17,68,0,'2026-07-17 17:29:29'),(188,6,18,72,0,'2026-07-17 17:29:31'),(189,6,19,79,0,'2026-07-17 17:29:33'),(190,6,20,83,0,'2026-07-17 17:29:35'),(191,6,21,87,0,'2026-07-17 17:29:38'),(192,6,22,95,5,'2026-07-17 17:29:44'),(194,6,23,101,5,'2026-07-17 17:29:46'),(195,6,24,104,2,'2026-07-17 17:29:51'),(196,6,25,111,3,'2026-07-17 17:29:54'),(197,6,26,116,2,'2026-07-17 17:29:59'),(199,6,27,126,6,'2026-07-17 17:30:02'),(200,6,28,131,5,'2026-07-17 17:30:05'),(201,6,29,136,4,'2026-07-17 17:30:08'),(202,6,30,142,4,'2026-07-17 17:30:11'),(203,6,31,146,2,'2026-07-17 17:30:14'),(204,6,32,155,5,'2026-07-17 17:30:17'),(205,6,33,161,5,'2026-07-17 17:30:19'),(206,6,34,166,4,'2026-07-17 17:30:22'),(207,6,35,172,4,'2026-07-17 17:30:26'),(208,6,36,179,5,'2026-07-17 17:30:28'),(209,6,37,183,3,'2026-07-17 17:30:33'),(210,6,38,188,2,'2026-07-17 17:30:35'),(211,6,39,197,5,'2026-07-17 17:30:38'),(212,7,1,3,2,'2026-07-18 04:35:34'),(213,7,2,7,2,'2026-07-18 04:35:36'),(214,7,3,11,2,'2026-07-18 04:35:37'),(215,7,4,15,2,'2026-07-18 04:35:39'),(216,7,5,19,2,'2026-07-18 04:35:40'),(217,7,6,23,2,'2026-07-18 04:35:41'),(218,7,7,27,2,'2026-07-18 04:35:43'),(219,7,8,31,2,'2026-07-18 04:35:46'),(220,7,9,35,2,'2026-07-18 04:36:22'),(221,7,10,39,2,'2026-07-18 04:36:23'),(222,7,11,43,2,'2026-07-18 04:36:24'),(223,7,12,47,2,'2026-07-18 04:36:25'),(224,7,13,51,2,'2026-07-18 04:36:27'),(225,7,14,55,2,'2026-07-18 04:36:28'),(226,7,15,59,2,'2026-07-18 04:36:30'),(227,7,16,66,3,'2026-07-18 04:36:33'),(228,7,17,70,2,'2026-07-18 04:36:35'),(229,7,18,76,2,'2026-07-18 04:36:37'),(230,7,19,81,2,'2026-07-18 04:36:39'),(231,7,20,85,2,'2026-07-18 04:36:41'),(232,7,21,89,2,'2026-07-18 04:36:44'),(233,7,22,94,4,'2026-07-18 04:37:14'),(235,7,23,100,4,'2026-07-18 04:37:24'),(236,7,24,107,5,'2026-07-18 04:37:26'),(237,7,25,111,3,'2026-07-18 04:37:28'),(238,7,26,116,2,'2026-07-18 04:37:38'),(239,7,27,124,4,'2026-07-18 04:37:41'),(240,7,28,130,4,'2026-07-18 04:37:42'),(241,7,29,136,4,'2026-07-18 04:37:44'),(242,7,30,141,3,'2026-07-18 04:37:46'),(243,7,31,147,3,'2026-07-18 04:37:47'),(244,7,32,154,4,'2026-07-18 04:37:49'),(245,7,33,160,4,'2026-07-18 04:38:00'),(246,7,34,165,3,'2026-07-18 04:38:02'),(247,7,35,171,3,'2026-07-18 04:38:04'),(248,7,36,177,3,'2026-07-18 04:38:06'),(249,7,37,184,4,'2026-07-18 04:38:40'),(250,7,38,189,3,'2026-07-18 04:38:41'),(251,7,39,196,4,'2026-07-18 04:38:43');
/*!40000 ALTER TABLE `assessment_session_answers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_sessions`
--

DROP TABLE IF EXISTS `assessment_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_sessions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `status` enum('in_progress','completed','timed_out') NOT NULL DEFAULT 'in_progress',
  `time_limit_seconds` int unsigned NOT NULL,
  `started_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `expires_at` datetime NOT NULL,
  `last_seen_question_id` int unsigned DEFAULT NULL,
  `bdi2_submission_id` int unsigned DEFAULT NULL,
  `pwb_submission_id` int unsigned DEFAULT NULL,
  `finalized_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `bdi2_submission_id` (`bdi2_submission_id`),
  KEY `pwb_submission_id` (`pwb_submission_id`),
  KEY `idx_user_status` (`user_id`,`status`),
  CONSTRAINT `assessment_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `assessment_sessions_ibfk_2` FOREIGN KEY (`bdi2_submission_id`) REFERENCES `assessment_submissions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `assessment_sessions_ibfk_3` FOREIGN KEY (`pwb_submission_id`) REFERENCES `assessment_submissions` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_sessions`
--

LOCK TABLES `assessment_sessions` WRITE;
/*!40000 ALTER TABLE `assessment_sessions` DISABLE KEYS */;
INSERT INTO `assessment_sessions` VALUES (4,51,'completed',2700,'2026-07-17 16:48:46','2026-07-17 17:33:46',39,12,13,'2026-07-17 16:50:53','2026-07-17 16:48:46'),(5,52,'completed',2700,'2026-07-17 17:25:53','2026-07-17 18:10:53',39,14,15,'2026-07-17 17:28:03','2026-07-17 17:25:53'),(6,53,'completed',2700,'2026-07-17 17:28:54','2026-07-17 18:13:54',39,16,17,'2026-07-17 17:30:41','2026-07-17 17:28:54'),(7,154,'completed',1200,'2026-07-18 04:35:05','2026-07-18 04:55:05',39,18,19,'2026-07-18 04:38:47','2026-07-18 04:35:05');
/*!40000 ALTER TABLE `assessment_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assessment_submissions`
--

DROP TABLE IF EXISTS `assessment_submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assessment_submissions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `type` enum('bdi2','pwb') NOT NULL,
  `total_score` int NOT NULL,
  `max_score` int NOT NULL,
  `category` varchar(50) NOT NULL,
  `category_percentage` decimal(5,2) DEFAULT NULL,
  `is_timed_out` tinyint(1) NOT NULL DEFAULT '0',
  `dimension_scores` json DEFAULT NULL,
  `submitted_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_type` (`user_id`,`type`),
  KEY `idx_type_category` (`type`,`category`),
  CONSTRAINT `assessment_submissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assessment_submissions`
--

LOCK TABLES `assessment_submissions` WRITE;
/*!40000 ALTER TABLE `assessment_submissions` DISABLE KEYS */;
INSERT INTO `assessment_submissions` VALUES (12,51,'bdi2',63,63,'Berat',NULL,0,NULL,'2026-07-17 16:50:53'),(13,51,'pwb',23,108,'Rendah',21.30,0,'{\"autonomy\": {\"label\": \"Otonomi\", \"score\": 3, \"category\": \"Rendah\", \"feedback\": \"Hasil menunjukkan bahwa Anda mungkin masih sering bergantung pada penilaian atau pendapat orang lain dalam mengambil keputusan. Cobalah melatih kepercayaan diri dan biasakan mengambil keputusan berdasarkan pertimbangan pribadi yang matang.\", \"max_score\": 18, \"percentage\": 16.67}, \"personal_growth\": {\"label\": \"Pertumbuhan Pribadi\", \"score\": 3, \"category\": \"Rendah\", \"feedback\": \"Anda mungkin sedang merasa kurang termotivasi untuk berkembang atau melakukan perubahan dalam hidup. Mulailah dengan menetapkan target kecil yang dapat dicapai secara bertahap agar proses pengembangan diri terasa lebih ringan dan bermakna.\", \"max_score\": 18, \"percentage\": 16.67}, \"purpose_in_life\": {\"label\": \"Tujuan Hidup\", \"score\": 3, \"category\": \"Rendah\", \"feedback\": \"Hasil menunjukkan bahwa Anda mungkin masih merasa bingung mengenai tujuan atau arah hidup yang ingin dicapai. Cobalah mulai menetapkan tujuan sederhana yang realistis dan sesuai dengan nilai-nilai yang Anda anggap penting.\", \"max_score\": 18, \"percentage\": 16.67}, \"self_acceptance\": {\"label\": \"Penerimaan Diri\", \"score\": 3, \"category\": \"Rendah\", \"feedback\": \"Hasil menunjukkan bahwa Anda mungkin masih sering merasa kurang puas terhadap diri sendiri atau pencapaian hidup. Cobalah mulai mengenali kelebihan yang dimiliki, menerima kekurangan sebagai bagian dari proses berkembang, serta jangan ragu mencari dukungan dari orang terdekat apabila diperlukan.\", \"max_score\": 18, \"percentage\": 16.67}, \"positive_relations\": {\"label\": \"Hubungan Positif dengan Orang Lain\", \"score\": 3, \"category\": \"Rendah\", \"feedback\": \"Anda mungkin sedang mengalami kesulitan dalam membangun hubungan yang dekat atau merasa kurang memiliki dukungan sosial. Cobalah mulai membuka komunikasi dengan orang yang dipercaya, karena memiliki hubungan sosial yang sehat dapat membantu menjaga kesejahteraan psikologis.\", \"max_score\": 18, \"percentage\": 16.67}, \"environmental_mastery\": {\"label\": \"Penguasaan Lingkungan\", \"score\": 8, \"category\": \"Rendah\", \"feedback\": \"Anda mungkin sedang mengalami kesulitan dalam mengelola berbagai tuntutan kehidupan sehari-hari sehingga lebih mudah merasa tertekan. Cobalah membagi tugas menjadi langkah-langkah kecil, membuat jadwal yang teratur, dan meminta bantuan apabila diperlukan.\", \"max_score\": 18, \"percentage\": 44.44}}','2026-07-17 16:50:53'),(14,52,'bdi2',32,63,'Berat',NULL,0,NULL,'2026-07-17 17:28:03'),(15,52,'pwb',70,108,'Sedang',64.81,0,'{\"autonomy\": {\"label\": \"Otonomi\", \"score\": 10, \"category\": \"Rendah\", \"feedback\": \"Hasil menunjukkan bahwa Anda mungkin masih sering bergantung pada penilaian atau pendapat orang lain dalam mengambil keputusan. Cobalah melatih kepercayaan diri dan biasakan mengambil keputusan berdasarkan pertimbangan pribadi yang matang.\", \"max_score\": 18, \"percentage\": 55.56}, \"personal_growth\": {\"label\": \"Pertumbuhan Pribadi\", \"score\": 11, \"category\": \"Sedang\", \"feedback\": \"Anda memiliki keinginan untuk berkembang, namun pada kondisi tertentu mungkin merasa ragu untuk mencoba hal baru atau keluar dari zona nyaman. Teruslah membuka diri terhadap pengalaman yang dapat memperkaya kemampuan dan wawasan Anda.\", \"max_score\": 18, \"percentage\": 61.11}, \"purpose_in_life\": {\"label\": \"Tujuan Hidup\", \"score\": 12, \"category\": \"Sedang\", \"feedback\": \"Anda telah memiliki beberapa tujuan dalam hidup, namun mungkin masih belum sepenuhnya yakin terhadap arah yang ingin dicapai. Luangkan waktu untuk mengevaluasi kembali prioritas dan target pribadi agar lebih terarah.\", \"max_score\": 18, \"percentage\": 66.67}, \"self_acceptance\": {\"label\": \"Penerimaan Diri\", \"score\": 14, \"category\": \"Sedang\", \"feedback\": \"Anda sudah memiliki penerimaan diri yang cukup baik, namun pada situasi tertentu masih mungkin merasa kurang puas terhadap diri sendiri atau pencapaian yang telah diraih. Cobalah lebih sering mengapresiasi proses dan kemajuan yang telah Anda lakukan daripada hanya berfokus pada kekurangan.\", \"max_score\": 18, \"percentage\": 77.78}, \"positive_relations\": {\"label\": \"Hubungan Positif dengan Orang Lain\", \"score\": 10, \"category\": \"Rendah\", \"feedback\": \"Anda mungkin sedang mengalami kesulitan dalam membangun hubungan yang dekat atau merasa kurang memiliki dukungan sosial. Cobalah mulai membuka komunikasi dengan orang yang dipercaya, karena memiliki hubungan sosial yang sehat dapat membantu menjaga kesejahteraan psikologis.\", \"max_score\": 18, \"percentage\": 55.56}, \"environmental_mastery\": {\"label\": \"Penguasaan Lingkungan\", \"score\": 13, \"category\": \"Sedang\", \"feedback\": \"Anda sudah cukup mampu mengatur aktivitas dan tanggung jawab sehari-hari, namun pada kondisi tertentu mungkin masih merasa kewalahan menghadapi berbagai tuntutan. Menyusun prioritas dan mengatur waktu dapat membantu meningkatkan kemampuan ini.\", \"max_score\": 18, \"percentage\": 72.22}}','2026-07-17 17:28:03'),(16,53,'bdi2',0,63,'Minimal',NULL,0,NULL,'2026-07-17 17:30:41'),(17,53,'pwb',83,108,'Sedang',76.85,0,'{\"autonomy\": {\"label\": \"Otonomi\", \"score\": 13, \"category\": \"Sedang\", \"feedback\": \"Anda sudah cukup mampu mengambil keputusan sendiri, namun pada kondisi tertentu masih mungkin dipengaruhi oleh pendapat atau tekanan dari lingkungan sekitar. Tetaplah mempertimbangkan masukan orang lain tanpa mengabaikan keyakinan dan nilai yang Anda miliki.\", \"max_score\": 18, \"percentage\": 72.22}, \"personal_growth\": {\"label\": \"Pertumbuhan Pribadi\", \"score\": 15, \"category\": \"Tinggi\", \"feedback\": \"Anda menunjukkan keinginan yang kuat untuk terus belajar, berkembang, dan meningkatkan kualitas diri. Sikap terbuka terhadap pengalaman baru merupakan modal penting dalam perkembangan pribadi.\", \"max_score\": 18, \"percentage\": 83.33}, \"purpose_in_life\": {\"label\": \"Tujuan Hidup\", \"score\": 13, \"category\": \"Sedang\", \"feedback\": \"Anda telah memiliki beberapa tujuan dalam hidup, namun mungkin masih belum sepenuhnya yakin terhadap arah yang ingin dicapai. Luangkan waktu untuk mengevaluasi kembali prioritas dan target pribadi agar lebih terarah.\", \"max_score\": 18, \"percentage\": 72.22}, \"self_acceptance\": {\"label\": \"Penerimaan Diri\", \"score\": 14, \"category\": \"Sedang\", \"feedback\": \"Anda sudah memiliki penerimaan diri yang cukup baik, namun pada situasi tertentu masih mungkin merasa kurang puas terhadap diri sendiri atau pencapaian yang telah diraih. Cobalah lebih sering mengapresiasi proses dan kemajuan yang telah Anda lakukan daripada hanya berfokus pada kekurangan.\", \"max_score\": 18, \"percentage\": 77.78}, \"positive_relations\": {\"label\": \"Hubungan Positif dengan Orang Lain\", \"score\": 13, \"category\": \"Sedang\", \"feedback\": \"Anda mampu menjalin hubungan dengan orang lain, namun dalam beberapa situasi mungkin masih merasa kesulitan untuk terbuka atau membangun kedekatan. Luangkan waktu untuk memperkuat komunikasi dan menjaga hubungan yang positif dengan orang-orang di sekitar Anda.\", \"max_score\": 18, \"percentage\": 72.22}, \"environmental_mastery\": {\"label\": \"Penguasaan Lingkungan\", \"score\": 15, \"category\": \"Tinggi\", \"feedback\": \"Anda mampu mengelola aktivitas, tanggung jawab, dan tantangan kehidupan sehari-hari dengan baik. Kemampuan ini menunjukkan bahwa Anda cukup adaptif dalam menghadapi perubahan maupun tekanan yang muncul.\", \"max_score\": 18, \"percentage\": 83.33}}','2026-07-17 17:30:41'),(18,154,'bdi2',43,63,'Berat',NULL,0,NULL,'2026-07-18 04:38:46'),(19,154,'pwb',68,108,'Sedang',62.96,0,'{\"autonomy\": {\"label\": \"Otonomi\", \"score\": 12, \"category\": \"Sedang\", \"feedback\": \"Anda sudah cukup mampu mengambil keputusan sendiri, namun pada kondisi tertentu masih mungkin dipengaruhi oleh pendapat atau tekanan dari lingkungan sekitar. Tetaplah mempertimbangkan masukan orang lain tanpa mengabaikan keyakinan dan nilai yang Anda miliki.\", \"max_score\": 18, \"percentage\": 66.67}, \"personal_growth\": {\"label\": \"Pertumbuhan Pribadi\", \"score\": 11, \"category\": \"Sedang\", \"feedback\": \"Anda memiliki keinginan untuk berkembang, namun pada kondisi tertentu mungkin merasa ragu untuk mencoba hal baru atau keluar dari zona nyaman. Teruslah membuka diri terhadap pengalaman yang dapat memperkaya kemampuan dan wawasan Anda.\", \"max_score\": 18, \"percentage\": 61.11}, \"purpose_in_life\": {\"label\": \"Tujuan Hidup\", \"score\": 11, \"category\": \"Sedang\", \"feedback\": \"Anda telah memiliki beberapa tujuan dalam hidup, namun mungkin masih belum sepenuhnya yakin terhadap arah yang ingin dicapai. Luangkan waktu untuk mengevaluasi kembali prioritas dan target pribadi agar lebih terarah.\", \"max_score\": 18, \"percentage\": 61.11}, \"self_acceptance\": {\"label\": \"Penerimaan Diri\", \"score\": 12, \"category\": \"Sedang\", \"feedback\": \"Anda sudah memiliki penerimaan diri yang cukup baik, namun pada situasi tertentu masih mungkin merasa kurang puas terhadap diri sendiri atau pencapaian yang telah diraih. Cobalah lebih sering mengapresiasi proses dan kemajuan yang telah Anda lakukan daripada hanya berfokus pada kekurangan.\", \"max_score\": 18, \"percentage\": 66.67}, \"positive_relations\": {\"label\": \"Hubungan Positif dengan Orang Lain\", \"score\": 10, \"category\": \"Rendah\", \"feedback\": \"Anda mungkin sedang mengalami kesulitan dalam membangun hubungan yang dekat atau merasa kurang memiliki dukungan sosial. Cobalah mulai membuka komunikasi dengan orang yang dipercaya, karena memiliki hubungan sosial yang sehat dapat membantu menjaga kesejahteraan psikologis.\", \"max_score\": 18, \"percentage\": 55.56}, \"environmental_mastery\": {\"label\": \"Penguasaan Lingkungan\", \"score\": 12, \"category\": \"Sedang\", \"feedback\": \"Anda sudah cukup mampu mengatur aktivitas dan tanggung jawab sehari-hari, namun pada kondisi tertentu mungkin masih merasa kewalahan menghadapi berbagai tuntutan. Menyusun prioritas dan mengatur waktu dapat membantu meningkatkan kemampuan ini.\", \"max_score\": 18, \"percentage\": 66.67}}','2026-07-18 04:38:47');
/*!40000 ALTER TABLE `assessment_submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_konseling`
--

DROP TABLE IF EXISTS `booking_konseling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_konseling` (
  `booking_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `konselor_id` int NOT NULL,
  `jadwal_id` int DEFAULT NULL,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `keluhan` text,
  `status` enum('Pending','Confirmed','Completed','Cancelled','No Show') DEFAULT 'Pending',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`booking_id`),
  KEY `user_id` (`user_id`),
  KEY `konselor_id` (`konselor_id`),
  KEY `jadwal_id` (`jadwal_id`),
  CONSTRAINT `booking_konseling_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `booking_konseling_ibfk_2` FOREIGN KEY (`konselor_id`) REFERENCES `konselor` (`konselor_id`),
  CONSTRAINT `booking_konseling_ibfk_3` FOREIGN KEY (`jadwal_id`) REFERENCES `konselor_jadwal` (`jadwal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_konseling`
--

LOCK TABLES `booking_konseling` WRITE;
/*!40000 ALTER TABLE `booking_konseling` DISABLE KEYS */;
INSERT INTO `booking_konseling` VALUES (4,52,4,166,'2026-07-20','09:00:00','11:00:00',NULL,'Completed','2026-07-17 18:34:20'),(9,51,4,204,'2026-07-18','02:05:00','08:00:00',NULL,'Completed','2026-07-17 19:06:55'),(10,52,4,204,'2026-07-18','02:05:00','08:00:00',NULL,'Completed','2026-07-17 19:07:25'),(11,53,4,204,'2026-07-18','02:05:00','08:00:00',NULL,'Completed','2026-07-17 19:07:52'),(12,154,4,206,'2026-07-18','11:50:00','14:00:00',NULL,'Completed','2026-07-18 04:51:54'),(13,154,4,206,'2026-07-18','11:50:00','14:00:00',NULL,'Confirmed','2026-07-18 05:22:07');
/*!40000 ALTER TABLE `booking_konseling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_logs`
--

DROP TABLE IF EXISTS `chat_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_logs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `sender` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  KEY `fk_chatlogs_user` (`user_id`),
  CONSTRAINT `fk_chatlogs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_logs`
--

LOCK TABLES `chat_logs` WRITE;
/*!40000 ALTER TABLE `chat_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `chat_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_messages`
--

DROP TABLE IF EXISTS `chat_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `chat_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `sender_id` int DEFAULT NULL,
  `receiver_id` int DEFAULT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_chatmsgs_user` (`user_id`),
  KEY `fk_chat_messages_sender` (`sender_id`),
  CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_chat_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_chatmsgs_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_messages`
--

LOCK TABLES `chat_messages` WRITE;
/*!40000 ALTER TABLE `chat_messages` DISABLE KEYS */;
INSERT INTO `chat_messages` VALUES (24,51,NULL,41,'Selamat malam, Pak Andi','2026-07-17 18:00:21',1),(25,41,NULL,51,'Malam mahasiswa 001','2026-07-17 18:00:38',0),(26,51,NULL,41,'Saya ingin konsultasi pak','2026-07-17 18:01:01',1),(27,41,NULL,51,'Baik, silakan. Apa yang bisa dibantu?','2026-07-17 18:01:19',0),(28,51,NULL,41,'Begini pak','2026-07-17 18:02:41',1),(29,41,NULL,51,'Oh begitu','2026-07-17 18:02:54',0),(30,51,NULL,41,'Iya begitu pak','2026-07-17 18:03:16',1),(32,51,NULL,41,'Pak','2026-07-17 18:29:20',1),(33,41,NULL,51,'Oke, done','2026-07-17 18:29:44',0),(34,52,NULL,41,'Halo dok','2026-07-17 18:35:24',1),(35,41,NULL,52,'Yes','2026-07-17 18:36:37',0),(36,41,NULL,52,'Done','2026-07-17 18:36:41',0),(37,53,NULL,41,'Test','2026-07-17 19:11:15',1),(38,41,NULL,53,'Oit','2026-07-17 19:11:35',0),(39,52,NULL,41,'Oke','2026-07-17 19:12:36',1),(40,41,NULL,52,'Done ya','2026-07-17 19:12:47',0),(41,53,NULL,41,'Done dok','2026-07-17 19:13:43',1),(42,41,NULL,53,'Oke','2026-07-17 19:13:54',0),(43,51,NULL,41,'Perpanjang dok','2026-07-17 19:14:25',1),(44,154,NULL,41,'Oi bang','2026-07-18 05:00:46',1),(45,41,NULL,154,'Oi','2026-07-18 05:01:04',0),(46,154,NULL,41,'Test','2026-07-18 05:01:58',1);
/*!40000 ALTER TABLE `chat_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_tips`
--

DROP TABLE IF EXISTS `daily_tips`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_tips` (
  `id` int NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `title` text,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `daily_tips_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_tips`
--

LOCK TABLES `daily_tips` WRITE;
/*!40000 ALTER TABLE `daily_tips` DISABLE KEYS */;
INSERT INTO `daily_tips` VALUES (26,'TEST TIPS',1,41,'2026-07-18 05:24:24','2026-07-18 05:24:24','APAANTUH'),(27,'TEST 2',1,41,'2026-07-18 05:25:22','2026-07-18 05:25:22','CONTOH'),(28,'CONTOH 3',1,41,'2026-07-18 05:25:33','2026-07-18 05:25:33','TEST');
/*!40000 ALTER TABLE `daily_tips` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diary_entries`
--

DROP TABLE IF EXISTS `diary_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diary_entries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `entry_date` date DEFAULT NULL,
  `judul` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_general_ci,
  `situasi` text COLLATE utf8mb4_general_ci,
  `pikiran_awal` text COLLATE utf8mb4_general_ci,
  `emosi_list` json DEFAULT NULL,
  `emosi_lainnya` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `intensitas_emosi` tinyint DEFAULT NULL,
  `reaksi_fisik_list` json DEFAULT NULL,
  `reaksi_fisik_lainnya` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `perilaku` text COLLATE utf8mb4_general_ci,
  `self_reflection` text COLLATE utf8mb4_general_ci,
  `gratitude_list` json DEFAULT NULL,
  `rencana_besok` text COLLATE utf8mb4_general_ci,
  `mood_level` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL COMMENT '1',
  `shared_konselor_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_diary_user` (`user_id`),
  KEY `fk_diary_shared_konselor` (`shared_konselor_id`),
  CONSTRAINT `fk_diary_shared_konselor` FOREIGN KEY (`shared_konselor_id`) REFERENCES `konselor` (`konselor_id`) ON DELETE SET NULL,
  CONSTRAINT `fk_diary_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diary_entries`
--

LOCK TABLES `diary_entries` WRITE;
/*!40000 ALTER TABLE `diary_entries` DISABLE KEYS */;
INSERT INTO `diary_entries` VALUES (14,154,'2026-07-18',NULL,NULL,'Test Edit','Test','[\"Kecewa\"]',NULL,3,'[\"Tegang\"]',NULL,'Test','Test','[\"Test\", \"Test\", \"Test\"]','Gatau',NULL,1,NULL,'2026-07-18 04:46:31'),(15,154,'2026-07-18',NULL,NULL,'Test','Test','[\"Kecewa\"]',NULL,4,'[\"Jantung berdebar\"]',NULL,'Test',NULL,'[\"Test\", \"Test\", \"Test\"]',NULL,NULL,0,4,'2026-07-18 05:23:02');
/*!40000 ALTER TABLE `diary_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diary_responses`
--

DROP TABLE IF EXISTS `diary_responses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diary_responses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `diary_id` int DEFAULT NULL,
  `konselor_id` int DEFAULT NULL,
  `response` text COLLATE utf8mb4_general_ci,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_diary_responses_diary` (`diary_id`),
  CONSTRAINT `diary_responses_ibfk_1` FOREIGN KEY (`id`) REFERENCES `diary_entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_diary_responses_diary` FOREIGN KEY (`diary_id`) REFERENCES `diary_entries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diary_responses`
--

LOCK TABLES `diary_responses` WRITE;
/*!40000 ALTER TABLE `diary_responses` DISABLE KEYS */;
/*!40000 ALTER TABLE `diary_responses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fakultas`
--

DROP TABLE IF EXISTS `fakultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fakultas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fakultas`
--

LOCK TABLES `fakultas` WRITE;
/*!40000 ALTER TABLE `fakultas` DISABLE KEYS */;
INSERT INTO `fakultas` VALUES (12,'Fakultas Ilmu Sosial dan Ilmu Politik'),(13,'Fakultas Keguruan dan Ilmu Pendidikan'),(14,'Fakultas Ekonomi'),(15,'Fakultas Pertanian'),(16,'Fakultas Studi Islam'),(17,'Fakultas Teknik'),(18,'Fakultas Kesehatan Masyarakat'),(19,'Fakultas Hukum'),(20,'Fakultas Teknologi Informasi'),(21,'Fakultas Farmasi');
/*!40000 ALTER TABLE `fakultas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jurusan`
--

DROP TABLE IF EXISTS `jurusan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jurusan` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fakultas_id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fakultas_id` (`fakultas_id`),
  CONSTRAINT `jurusan_fakultas_fk` FOREIGN KEY (`fakultas_id`) REFERENCES `fakultas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jurusan`
--

LOCK TABLES `jurusan` WRITE;
/*!40000 ALTER TABLE `jurusan` DISABLE KEYS */;
INSERT INTO `jurusan` VALUES (73,12,'Ilmu Komunikasi'),(74,12,'Ilmu Administrasi Publik'),(75,13,'Pendidikan Bahasa Inggris'),(76,13,'Bimbingan dan Konseling'),(77,13,'Pendidikan Kimia'),(78,13,'Pendidikan Olah Raga'),(79,14,'Manajemen'),(80,15,'Peternakan'),(81,15,'Agribisnis'),(82,16,'Hukum Ekonomi Syari\'ah'),(83,16,'Ekonomi Syari\'ah'),(84,16,'Pendidikan Guru Madrasah Ibtidaiyah'),(85,17,'Teknik Mesin'),(86,17,'Teknik Sipil'),(87,17,'Teknik Elektro'),(88,17,'Teknik Industri'),(89,18,'Kesehatan Masyarakat'),(90,19,'Ilmu Hukum'),(91,20,'Teknik Informatika'),(92,20,'Sistem Informasi'),(93,21,'Farmasi');
/*!40000 ALTER TABLE `jurusan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konselor`
--

DROP TABLE IF EXISTS `konselor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `konselor` (
  `konselor_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `nomor_registrasi` varchar(50) NOT NULL,
  `profesi` enum('Psikolog','Konselor','Psikiater') NOT NULL,
  `spesialisasi` varchar(100) DEFAULT NULL,
  `pendidikan` varchar(150) DEFAULT NULL,
  `pengalaman_tahun` int DEFAULT '0',
  `bahasa` varchar(100) DEFAULT NULL,
  `biaya_konsultasi` decimal(12,2) DEFAULT '0.00',
  `durasi_sesi` int DEFAULT '60',
  `metode_konsultasi` enum('Online','Offline','Hybrid') DEFAULT 'Online',
  `foto_profil` varchar(255) DEFAULT NULL,
  `biografi` text,
  `status_verifikasi` tinyint(1) DEFAULT '0',
  `status_aktif` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`konselor_id`),
  UNIQUE KEY `nomor_registrasi` (`nomor_registrasi`),
  KEY `fk_konselor_user` (`user_id`),
  CONSTRAINT `fk_konselor_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konselor`
--

LOCK TABLES `konselor` WRITE;
/*!40000 ALTER TABLE `konselor` DISABLE KEYS */;
INSERT INTO `konselor` VALUES (4,41,'STR-2026-001','Psikolog','Gangguan Kecemasan (Anxiety)','Prof. Psikolog',4,'Indonesia, English',75000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(5,42,'STR-2026-002','Psikolog','Depresi','Prof. Psikolog',5,'Indonesia, English',100000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(6,43,'STR-2026-003','Psikolog','Konseling Akademik','Prof. Psikolog',6,'Indonesia, English',125000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(7,44,'STR-2026-004','Psikolog','Konseling Remaja','Prof. Psikolog',7,'Indonesia, English',150000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(8,45,'STR-2026-005','Psikolog','Trauma Healing','Prof. Psikolog',8,'Indonesia, English',50000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(9,46,'STR-2026-006','Psikolog','Pengembangan Diri','Prof. Psikolog',9,'Indonesia, English',75000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(10,47,'STR-2026-007','Psikolog','Manajemen Stres','Prof. Psikolog',10,'Indonesia, English',100000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(11,48,'STR-2026-008','Psikolog','Konseling Keluarga','Prof. Psikolog',11,'Indonesia, English',125000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(12,49,'STR-2026-009','Psikolog','Relationship Counseling','Prof. Psikolog',12,'Indonesia, English',150000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12'),(13,50,'STR-2026-010','Psikolog','Self Development','Prof. Psikolog',13,'Indonesia, English',50000.00,60,'Hybrid',NULL,'Berpengalaman menangani kesehatan mental mahasiswa.',1,1,'2026-07-17 17:13:12','2026-07-17 17:13:12');
/*!40000 ALTER TABLE `konselor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konselor_jadwal`
--

DROP TABLE IF EXISTS `konselor_jadwal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `konselor_jadwal` (
  `jadwal_id` int NOT NULL AUTO_INCREMENT,
  `konselor_id` int NOT NULL,
  `tanggal` date NOT NULL,
  `jam_mulai` time NOT NULL,
  `jam_selesai` time NOT NULL,
  `kuota` int DEFAULT '10',
  `status_aktif` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`jadwal_id`),
  KEY `fk_jadwal_konselor` (`konselor_id`),
  CONSTRAINT `fk_jadwal_konselor` FOREIGN KEY (`konselor_id`) REFERENCES `konselor` (`konselor_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=207 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konselor_jadwal`
--

LOCK TABLES `konselor_jadwal` WRITE;
/*!40000 ALTER TABLE `konselor_jadwal` DISABLE KEYS */;
INSERT INTO `konselor_jadwal` VALUES (151,11,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(152,11,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(153,11,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(154,11,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(155,11,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(156,12,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(157,12,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(158,12,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(159,12,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(160,12,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(161,13,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(162,13,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(163,13,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(164,13,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(165,13,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(166,4,'2026-07-17','09:00:00','11:00:00',10,0,'2026-07-17 17:14:10'),(167,4,'2026-07-17','10:00:00','12:00:00',10,0,'2026-07-17 17:14:10'),(168,4,'2026-07-17','13:00:00','15:00:00',10,0,'2026-07-17 17:14:10'),(169,4,'2026-07-17','14:00:00','16:00:00',10,0,'2026-07-17 17:14:10'),(170,4,'2026-07-17','15:00:00','17:00:00',10,0,'2026-07-17 17:14:10'),(171,5,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(172,5,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(173,5,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(174,5,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(175,5,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(176,6,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(177,6,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(178,6,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(179,6,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(180,6,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(181,7,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(182,7,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(183,7,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(184,7,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(185,7,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(186,8,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(187,8,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(188,8,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(189,8,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(190,8,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(191,9,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(192,9,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(193,9,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(194,9,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(195,9,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(196,10,'2026-07-17','09:00:00','11:00:00',10,1,'2026-07-17 17:14:10'),(197,10,'2026-07-17','10:00:00','12:00:00',10,1,'2026-07-17 17:14:10'),(198,10,'2026-07-17','13:00:00','15:00:00',10,1,'2026-07-17 17:14:10'),(199,10,'2026-07-17','14:00:00','16:00:00',10,1,'2026-07-17 17:14:10'),(200,10,'2026-07-17','15:00:00','17:00:00',10,1,'2026-07-17 17:14:10'),(204,4,'2026-07-18','02:05:00','08:00:00',3,0,'2026-07-17 19:06:08'),(206,4,'2026-07-18','11:50:00','14:00:00',3,1,'2026-07-18 04:51:18');
/*!40000 ALTER TABLE `konselor_jadwal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `konselor_sertifikasi`
--

DROP TABLE IF EXISTS `konselor_sertifikasi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `konselor_sertifikasi` (
  `sertifikasi_id` int NOT NULL AUTO_INCREMENT,
  `konselor_id` int NOT NULL,
  `nama_sertifikasi` varchar(200) NOT NULL,
  `penerbit` varchar(150) DEFAULT NULL,
  `nomor_sertifikat` varchar(100) DEFAULT NULL,
  `tahun` year DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sertifikasi_id`),
  KEY `konselor_id` (`konselor_id`),
  CONSTRAINT `konselor_sertifikasi_ibfk_1` FOREIGN KEY (`konselor_id`) REFERENCES `konselor` (`konselor_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `konselor_sertifikasi`
--

LOCK TABLES `konselor_sertifikasi` WRITE;
/*!40000 ALTER TABLE `konselor_sertifikasi` DISABLE KEYS */;
INSERT INTO `konselor_sertifikasi` VALUES (21,4,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-001',2023,'2026-07-17 17:15:33'),(22,4,'Mental Health First Aid','HIMPSI','MHFA-001',2024,'2026-07-17 17:15:33'),(23,5,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-002',2023,'2026-07-17 17:15:33'),(24,5,'Mental Health First Aid','HIMPSI','MHFA-002',2024,'2026-07-17 17:15:33'),(25,6,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-003',2023,'2026-07-17 17:15:33'),(26,6,'Mental Health First Aid','HIMPSI','MHFA-003',2024,'2026-07-17 17:15:33'),(27,7,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-004',2023,'2026-07-17 17:15:33'),(28,7,'Mental Health First Aid','HIMPSI','MHFA-004',2024,'2026-07-17 17:15:33'),(29,8,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-005',2023,'2026-07-17 17:15:33'),(30,8,'Mental Health First Aid','HIMPSI','MHFA-005',2024,'2026-07-17 17:15:33'),(31,9,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-006',2023,'2026-07-17 17:15:33'),(32,9,'Mental Health First Aid','HIMPSI','MHFA-006',2024,'2026-07-17 17:15:33'),(33,10,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-007',2023,'2026-07-17 17:15:33'),(34,10,'Mental Health First Aid','HIMPSI','MHFA-007',2024,'2026-07-17 17:15:33'),(35,11,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-008',2023,'2026-07-17 17:15:33'),(36,11,'Mental Health First Aid','HIMPSI','MHFA-008',2024,'2026-07-17 17:15:33'),(37,12,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-009',2023,'2026-07-17 17:15:33'),(38,12,'Mental Health First Aid','HIMPSI','MHFA-009',2024,'2026-07-17 17:15:33'),(39,13,'Cognitive Behavioral Therapy (CBT)','HIMPSI','CBT-010',2023,'2026-07-17 17:15:33'),(40,13,'Mental Health First Aid','HIMPSI','MHFA-010',2024,'2026-07-17 17:15:33');
/*!40000 ALTER TABLE `konselor_sertifikasi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log_login`
--

DROP TABLE IF EXISTS `log_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `log_login` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `waktu_login` datetime DEFAULT CURRENT_TIMESTAMP,
  `ip_address` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log_login`
--

LOCK TABLES `log_login` WRITE;
/*!40000 ALTER TABLE `log_login` DISABLE KEYS */;
INSERT INTO `log_login` VALUES (1,3,'2026-04-30 13:33:06','::1'),(2,3,'2026-05-04 11:28:08','::1'),(3,18,'2026-05-04 11:41:53','::1'),(4,3,'2026-05-04 11:44:30','::1'),(5,18,'2026-05-04 12:02:43','::1'),(6,3,'2026-05-05 15:16:44','::1'),(7,18,'2026-05-05 15:34:08','::1'),(8,18,'2026-05-05 15:35:13','::1'),(9,3,'2026-05-05 15:35:55','::1'),(10,18,'2026-05-05 15:49:19','::1'),(11,3,'2026-05-05 15:53:31','::1'),(12,3,'2026-05-06 11:17:17','::1'),(13,16,'2026-05-06 14:22:49','::1'),(14,16,'2026-05-06 14:25:49','::1'),(15,3,'2026-05-06 14:26:57','::1'),(16,3,'2026-05-07 11:53:26','::1'),(17,3,'2026-05-08 11:28:34','::1'),(18,3,'2026-05-11 11:19:56','::1'),(19,18,'2026-05-11 14:41:20','::1'),(20,18,'2026-05-11 14:41:59','::1'),(21,3,'2026-05-11 14:45:24','::1'),(22,3,'2026-05-11 15:21:11','::1'),(23,3,'2026-05-12 11:49:52','::1'),(24,18,'2026-05-12 11:52:25','::1'),(25,3,'2026-05-12 11:59:54','::1'),(26,3,'2026-05-13 13:32:58','::1'),(27,18,'2026-05-13 13:50:52','::1'),(28,3,'2026-05-13 15:19:25','::1'),(29,3,'2026-05-16 14:21:34','::1'),(30,18,'2026-05-16 14:41:36','::1'),(31,3,'2026-05-16 15:05:28','::1'),(32,18,'2026-05-16 15:33:46','::1'),(33,3,'2026-05-16 16:16:46','::1'),(34,3,'2026-05-18 11:23:27','::1'),(35,18,'2026-05-18 13:23:00','::1'),(36,3,'2026-05-18 13:29:13','::1'),(37,18,'2026-05-18 14:08:44','::1'),(38,18,'2026-05-18 14:11:08','::1'),(39,3,'2026-05-18 14:34:56','::1'),(40,3,'2026-05-19 10:44:18','::1'),(41,3,'2026-05-19 10:57:08','::1'),(42,3,'2026-05-19 12:14:09','::1'),(43,16,'2026-05-19 14:13:54','::1'),(44,3,'2026-05-19 14:32:42','::1'),(45,3,'2026-05-20 12:20:24','::1'),(46,3,'2026-05-20 14:03:16','::1'),(47,18,'2026-05-20 15:39:35','::1'),(48,3,'2026-05-20 15:40:12','::1'),(49,3,'2026-05-21 11:13:35','::1'),(50,3,'2026-05-21 13:29:51','::1'),(51,3,'2026-07-02 14:40:15','::1'),(52,3,'2026-07-06 14:39:21','::1'),(53,3,'2026-07-07 11:17:30','::1'),(54,22,'2026-07-07 11:22:39','::1'),(55,22,'2026-07-07 11:29:07','::1'),(56,3,'2026-07-07 11:52:26','::1'),(57,3,'2026-07-07 15:25:47','::1'),(58,3,'2026-07-09 16:01:17','::1'),(59,3,'2026-07-10 08:29:30','::1'),(60,3,'2026-07-10 08:59:11','::1'),(61,25,'2026-07-10 08:59:30','::1'),(62,25,'2026-07-10 09:19:08','::1'),(63,25,'2026-07-10 09:23:05','::1'),(64,25,'2026-07-10 13:21:54','::1'),(65,25,'2026-07-10 13:39:01','::1'),(66,3,'2026-07-10 13:44:56','::1'),(67,3,'2026-07-10 13:47:12','::1'),(68,3,'2026-07-10 14:08:41','::1'),(69,25,'2026-07-14 11:52:02','::1'),(70,25,'2026-07-14 11:55:49','::1'),(71,3,'2026-07-14 11:57:16','::1'),(72,25,'2026-07-14 12:01:51','::1'),(73,25,'2026-07-14 12:02:27','::1'),(74,3,'2026-07-14 12:04:59','::1'),(75,3,'2026-07-14 12:12:00','::1'),(76,25,'2026-07-14 12:15:26','::1'),(77,15,'2026-07-14 12:19:30','::1'),(78,25,'2026-07-14 12:30:24','::1'),(79,3,'2026-07-14 12:33:22','::1'),(80,25,'2026-07-14 12:42:53','::1'),(81,3,'2026-07-14 12:44:56','::1'),(82,25,'2026-07-14 12:46:47','::1'),(83,15,'2026-07-14 12:52:18','::1');
/*!40000 ALTER TABLE `log_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mahasiswa`
--

DROP TABLE IF EXISTS `mahasiswa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mahasiswa` (
  `id_mahasiswa` int NOT NULL AUTO_INCREMENT,
  `id` int NOT NULL,
  `npm` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `program_studi` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `fakultas` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `jenis_kelamin` enum('L','P') COLLATE utf8mb4_general_ci NOT NULL,
  `no_hp` varchar(15) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_mahasiswa`),
  UNIQUE KEY `npm` (`npm`),
  KEY `id` (`id`),
  CONSTRAINT `mahasiswa_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mahasiswa`
--

LOCK TABLES `mahasiswa` WRITE;
/*!40000 ALTER TABLE `mahasiswa` DISABLE KEYS */;
/*!40000 ALTER TABLE `mahasiswa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `monitoring_periods`
--

DROP TABLE IF EXISTS `monitoring_periods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `monitoring_periods` (
  `monitoring_id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `user_id` int NOT NULL,
  `konselor_id` int NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`monitoring_id`),
  UNIQUE KEY `booking_id` (`booking_id`),
  KEY `user_id` (`user_id`),
  KEY `konselor_id` (`konselor_id`),
  CONSTRAINT `monitoring_periods_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `booking_konseling` (`booking_id`) ON DELETE CASCADE,
  CONSTRAINT `monitoring_periods_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `monitoring_periods_ibfk_3` FOREIGN KEY (`konselor_id`) REFERENCES `konselor` (`konselor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `monitoring_periods`
--

LOCK TABLES `monitoring_periods` WRITE;
/*!40000 ALTER TABLE `monitoring_periods` DISABLE KEYS */;
INSERT INTO `monitoring_periods` VALUES (4,9,51,4,'2026-07-17','2026-07-16','2026-07-17 19:09:46'),(5,10,52,4,'2026-07-17','2026-07-16','2026-07-17 19:09:48'),(6,11,53,4,'2026-07-17','2026-07-16','2026-07-17 19:09:49'),(7,12,154,4,'2026-07-18','2026-07-17','2026-07-18 04:56:55'),(8,13,154,4,'2026-07-18','2026-07-19','2026-07-18 05:22:18');
/*!40000 ALTER TABLE `monitoring_periods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `is_read` tinyint(1) DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_notifications_user` (`user_id`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `questions`
--

DROP TABLE IF EXISTS `questions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `questions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `question` text COLLATE utf8mb4_general_ci,
  `kategori` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `bobot_skor` int NOT NULL,
  `tipe_pilihan` varchar(50) COLLATE utf8mb4_general_ci DEFAULT 'Likert Scale',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `questions`
--

LOCK TABLES `questions` WRITE;
/*!40000 ALTER TABLE `questions` DISABLE KEYS */;
/*!40000 ALTER TABLE `questions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rating_konselor`
--

DROP TABLE IF EXISTS `rating_konselor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rating_konselor` (
  `rating_id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `user_id` int NOT NULL,
  `konselor_id` int NOT NULL,
  `rating` tinyint NOT NULL,
  `komentar` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rating_id`),
  UNIQUE KEY `booking_id` (`booking_id`),
  KEY `user_id` (`user_id`),
  KEY `konselor_id` (`konselor_id`),
  CONSTRAINT `rating_konselor_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `booking_konseling` (`booking_id`) ON DELETE CASCADE,
  CONSTRAINT `rating_konselor_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `rating_konselor_ibfk_3` FOREIGN KEY (`konselor_id`) REFERENCES `konselor` (`konselor_id`),
  CONSTRAINT `rating_konselor_chk_1` CHECK ((`rating` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rating_konselor`
--

LOCK TABLES `rating_konselor` WRITE;
/*!40000 ALTER TABLE `rating_konselor` DISABLE KEYS */;
/*!40000 ALTER TABLE `rating_konselor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sesi_konseling`
--

DROP TABLE IF EXISTS `sesi_konseling`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sesi_konseling` (
  `sesi_id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `catatan_konselor` text,
  `rekomendasi` text,
  `tindak_lanjut` text,
  `durasi` int DEFAULT NULL,
  `selesai_pada` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sesi_id`),
  UNIQUE KEY `booking_id` (`booking_id`),
  CONSTRAINT `sesi_konseling_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `booking_konseling` (`booking_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sesi_konseling`
--

LOCK TABLES `sesi_konseling` WRITE;
/*!40000 ALTER TABLE `sesi_konseling` DISABLE KEYS */;
/*!40000 ALTER TABLE `sesi_konseling` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `setting_value` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `system_settings_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `nama_lengkap` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `npm` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fakultas` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `jurusan` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `no_hp` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `role` enum('admin','mahasiswa','konselor') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `profile_image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` enum('pending','active','rejected') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `approved_by` int DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (39,'Admin Sistem','admin01','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Administrator Sistem',NULL,'Laki-laki',NULL,NULL,'081111111111','raendy.andhika98@gmail.com','admin',NULL,'active',NULL,'2026-07-17 16:36:48','2026-07-17 16:36:48'),(40,'Admin Akademik','admin02','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Administrator Akademik',NULL,'Perempuan',NULL,NULL,'081111111112','raendy.andhika98@gmail.com','admin',NULL,'active',NULL,'2026-07-17 16:36:48','2026-07-17 16:36:48'),(41,'Dr. Andi Prakoso','konselor01','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Dr. Andi Prakoso',NULL,'Laki-laki',NULL,NULL,'081240000001','konselor01@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(42,'Dra. Siti Rahma','konselor02','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Dra. Siti Rahma',NULL,'Perempuan',NULL,NULL,'081240000002','konselor02@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(43,'Dr. Budi Santoso','konselor03','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Dr. Budi Santoso',NULL,'Laki-laki',NULL,NULL,'081240000003','konselor03@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(44,'M.Psi. Rina Putri','konselor04','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Rina Putri',NULL,'Perempuan',NULL,NULL,'081240000004','konselor04@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(45,'Dr. Agus Setiawan','konselor05','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Dr. Agus Setiawan',NULL,'Laki-laki',NULL,NULL,'081240000005','konselor05@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(46,'M.Psi. Maya Sari','konselor06','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Maya Sari',NULL,'Perempuan',NULL,NULL,'081240000006','konselor06@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(47,'Dr. Fajar Hidayat','konselor07','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Dr. Fajar Hidayat',NULL,'Laki-laki',NULL,NULL,'081240000007','konselor07@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(48,'M.Psi. Intan Permata','konselor08','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Intan Permata',NULL,'Perempuan',NULL,NULL,'081240000008','konselor08@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(49,'Dr. Reza Maulana','konselor09','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Dr. Reza Maulana',NULL,'Laki-laki',NULL,NULL,'081240000009','konselor09@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(50,'M.Psi. Nabila Putri','konselor10','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Nabila Putri',NULL,'Perempuan',NULL,NULL,'081240000010','konselor10@uniska.ac.id','konselor',NULL,'active',1,'2026-07-17 16:38:48','2026-07-17 16:38:48'),(51,'Mahasiswa 001','student001','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 001','231000001','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000001','student001@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(52,'Mahasiswa 002','student002','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 002','231000002','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000002','student002@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(53,'Mahasiswa 003','student003','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 003','231000003','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000003','student003@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(54,'Mahasiswa 004','student004','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 004','231000004','Perempuan','Fakultas Teknik','Teknik Mesin','08123000004','student004@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(55,'Mahasiswa 005','student005','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 005','231000005','Laki-laki','Fakultas Ekonomi','Manajemen','08123000005','student005@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(56,'Mahasiswa 006','student006','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 006','231000006','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000006','student006@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(57,'Mahasiswa 007','student007','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 007','231000007','Laki-laki','Fakultas Farmasi','Farmasi','08123000007','student007@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(58,'Mahasiswa 008','student008','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 008','231000008','Perempuan','Fakultas Pertanian','Agribisnis','08123000008','student008@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(59,'Mahasiswa 009','student009','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 009','231000009','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000009','student009@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(60,'Mahasiswa 010','student010','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 010','231000010','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000010','student010@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(61,'Mahasiswa 011','student011','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 011','231000011','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000011','student011@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(62,'Mahasiswa 012','student012','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 012','231000012','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000012','student012@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(63,'Mahasiswa 013','student013','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 013','231000013','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000013','student013@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(64,'Mahasiswa 014','student014','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 014','231000014','Perempuan','Fakultas Teknik','Teknik Mesin','08123000014','student014@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(65,'Mahasiswa 015','student015','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 015','231000015','Laki-laki','Fakultas Ekonomi','Manajemen','08123000015','student015@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(66,'Mahasiswa 016','student016','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 016','231000016','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000016','student016@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(67,'Mahasiswa 017','student017','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 017','231000017','Laki-laki','Fakultas Farmasi','Farmasi','08123000017','student017@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(68,'Mahasiswa 018','student018','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 018','231000018','Perempuan','Fakultas Pertanian','Agribisnis','08123000018','student018@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(69,'Mahasiswa 019','student019','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 019','231000019','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000019','student019@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(70,'Mahasiswa 020','student020','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 020','231000020','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000020','student020@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(71,'Mahasiswa 021','student021','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 021','231000021','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000021','student021@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(72,'Mahasiswa 022','student022','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 022','231000022','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000022','student022@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(73,'Mahasiswa 023','student023','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 023','231000023','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000023','student023@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(74,'Mahasiswa 024','student024','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 024','231000024','Perempuan','Fakultas Teknik','Teknik Mesin','08123000024','student024@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(75,'Mahasiswa 025','student025','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 025','231000025','Laki-laki','Fakultas Ekonomi','Manajemen','08123000025','student025@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(76,'Mahasiswa 026','student026','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 026','231000026','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000026','student026@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(77,'Mahasiswa 027','student027','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 027','231000027','Laki-laki','Fakultas Farmasi','Farmasi','08123000027','student027@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(78,'Mahasiswa 028','student028','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 028','231000028','Perempuan','Fakultas Pertanian','Agribisnis','08123000028','student028@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(79,'Mahasiswa 029','student029','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 029','231000029','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000029','student029@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(80,'Mahasiswa 030','student030','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 030','231000030','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000030','student030@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(81,'Mahasiswa 031','student031','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 031','231000031','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000031','student031@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(82,'Mahasiswa 032','student032','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 032','231000032','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000032','student032@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(83,'Mahasiswa 033','student033','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 033','231000033','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000033','student033@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(84,'Mahasiswa 034','student034','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 034','231000034','Perempuan','Fakultas Teknik','Teknik Mesin','08123000034','student034@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(85,'Mahasiswa 035','student035','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 035','231000035','Laki-laki','Fakultas Ekonomi','Manajemen','08123000035','student035@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(86,'Mahasiswa 036','student036','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 036','231000036','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000036','student036@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(87,'Mahasiswa 037','student037','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 037','231000037','Laki-laki','Fakultas Farmasi','Farmasi','08123000037','student037@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(88,'Mahasiswa 038','student038','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 038','231000038','Perempuan','Fakultas Pertanian','Agribisnis','08123000038','student038@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(89,'Mahasiswa 039','student039','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 039','231000039','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000039','student039@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(90,'Mahasiswa 040','student040','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 040','231000040','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000040','student040@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(91,'Mahasiswa 041','student041','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 041','231000041','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000041','student041@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(92,'Mahasiswa 042','student042','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 042','231000042','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000042','student042@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(93,'Mahasiswa 043','student043','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 043','231000043','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000043','student043@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(94,'Mahasiswa 044','student044','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 044','231000044','Perempuan','Fakultas Teknik','Teknik Mesin','08123000044','student044@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(95,'Mahasiswa 045','student045','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 045','231000045','Laki-laki','Fakultas Ekonomi','Manajemen','08123000045','student045@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(96,'Mahasiswa 046','student046','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 046','231000046','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000046','student046@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(97,'Mahasiswa 047','student047','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 047','231000047','Laki-laki','Fakultas Farmasi','Farmasi','08123000047','student047@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(98,'Mahasiswa 048','student048','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 048','231000048','Perempuan','Fakultas Pertanian','Agribisnis','08123000048','student048@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(99,'Mahasiswa 049','student049','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 049','231000049','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000049','student049@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(100,'Mahasiswa 050','student050','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 050','231000050','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000050','student050@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(101,'Mahasiswa 051','student051','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 051','231000051','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000051','student051@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(102,'Mahasiswa 052','student052','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 052','231000052','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000052','student052@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(103,'Mahasiswa 053','student053','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 053','231000053','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000053','student053@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(104,'Mahasiswa 054','student054','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 054','231000054','Perempuan','Fakultas Teknik','Teknik Mesin','08123000054','student054@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(105,'Mahasiswa 055','student055','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 055','231000055','Laki-laki','Fakultas Ekonomi','Manajemen','08123000055','student055@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(106,'Mahasiswa 056','student056','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 056','231000056','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000056','student056@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(107,'Mahasiswa 057','student057','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 057','231000057','Laki-laki','Fakultas Farmasi','Farmasi','08123000057','student057@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(108,'Mahasiswa 058','student058','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 058','231000058','Perempuan','Fakultas Pertanian','Agribisnis','08123000058','student058@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(109,'Mahasiswa 059','student059','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 059','231000059','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000059','student059@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(110,'Mahasiswa 060','student060','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 060','231000060','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000060','student060@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(111,'Mahasiswa 061','student061','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 061','231000061','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000061','student061@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(112,'Mahasiswa 062','student062','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 062','231000062','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000062','student062@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(113,'Mahasiswa 063','student063','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 063','231000063','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000063','student063@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(114,'Mahasiswa 064','student064','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 064','231000064','Perempuan','Fakultas Teknik','Teknik Mesin','08123000064','student064@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(115,'Mahasiswa 065','student065','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 065','231000065','Laki-laki','Fakultas Ekonomi','Manajemen','08123000065','student065@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(116,'Mahasiswa 066','student066','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 066','231000066','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000066','student066@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(117,'Mahasiswa 067','student067','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 067','231000067','Laki-laki','Fakultas Farmasi','Farmasi','08123000067','student067@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(118,'Mahasiswa 068','student068','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 068','231000068','Perempuan','Fakultas Pertanian','Agribisnis','08123000068','student068@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(119,'Mahasiswa 069','student069','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 069','231000069','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000069','student069@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(120,'Mahasiswa 070','student070','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 070','231000070','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000070','student070@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(121,'Mahasiswa 071','student071','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 071','231000071','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000071','student071@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(122,'Mahasiswa 072','student072','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 072','231000072','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000072','student072@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(123,'Mahasiswa 073','student073','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 073','231000073','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000073','student073@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(124,'Mahasiswa 074','student074','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 074','231000074','Perempuan','Fakultas Teknik','Teknik Mesin','08123000074','student074@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(125,'Mahasiswa 075','student075','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 075','231000075','Laki-laki','Fakultas Ekonomi','Manajemen','08123000075','student075@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(126,'Mahasiswa 076','student076','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 076','231000076','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000076','student076@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(127,'Mahasiswa 077','student077','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 077','231000077','Laki-laki','Fakultas Farmasi','Farmasi','08123000077','student077@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(128,'Mahasiswa 078','student078','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 078','231000078','Perempuan','Fakultas Pertanian','Agribisnis','08123000078','student078@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(129,'Mahasiswa 079','student079','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 079','231000079','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000079','student079@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(130,'Mahasiswa 080','student080','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 080','231000080','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000080','student080@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(131,'Mahasiswa 081','student081','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 081','231000081','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000081','student081@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(132,'Mahasiswa 082','student082','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 082','231000082','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000082','student082@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(133,'Mahasiswa 083','student083','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 083','231000083','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000083','student083@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(134,'Mahasiswa 084','student084','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 084','231000084','Perempuan','Fakultas Teknik','Teknik Mesin','08123000084','student084@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(135,'Mahasiswa 085','student085','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 085','231000085','Laki-laki','Fakultas Ekonomi','Manajemen','08123000085','student085@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(136,'Mahasiswa 086','student086','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 086','231000086','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000086','student086@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(137,'Mahasiswa 087','student087','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 087','231000087','Laki-laki','Fakultas Farmasi','Farmasi','08123000087','student087@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(138,'Mahasiswa 088','student088','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 088','231000088','Perempuan','Fakultas Pertanian','Agribisnis','08123000088','student088@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(139,'Mahasiswa 089','student089','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 089','231000089','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000089','student089@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(140,'Mahasiswa 090','student090','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 090','231000090','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000090','student090@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(141,'Mahasiswa 091','student091','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 091','231000091','Laki-laki','Fakultas Teknologi Informasi','Teknik Informatika','08123000091','student091@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(142,'Mahasiswa 092','student092','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 092','231000092','Perempuan','Fakultas Teknologi Informasi','Sistem Informasi','08123000092','student092@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(143,'Mahasiswa 093','student093','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 093','231000093','Laki-laki','Fakultas Teknik','Teknik Sipil','08123000093','student093@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(144,'Mahasiswa 094','student094','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 094','231000094','Perempuan','Fakultas Teknik','Teknik Mesin','08123000094','student094@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(145,'Mahasiswa 095','student095','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 095','231000095','Laki-laki','Fakultas Ekonomi','Manajemen','08123000095','student095@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(146,'Mahasiswa 096','student096','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 096','231000096','Perempuan','Fakultas Hukum','Ilmu Hukum','08123000096','student096@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(147,'Mahasiswa 097','student097','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 097','231000097','Laki-laki','Fakultas Farmasi','Farmasi','08123000097','student097@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(148,'Mahasiswa 098','student098','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 098','231000098','Perempuan','Fakultas Pertanian','Agribisnis','08123000098','student098@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(149,'Mahasiswa 099','student099','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 099','231000099','Laki-laki','Fakultas Kesehatan Masyarakat','Kesehatan Masyarakat','08123000099','student099@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(150,'Mahasiswa 100','student100','$2y$10$y2Aa5845ffXmUC.rWuRRAe4uUMfxuV5PmLJegSKX1wQpUeoqkBpyG','Mahasiswa 100','231000100','Perempuan','Fakultas Ilmu Sosial dan Ilmu Politik','Ilmu Komunikasi','08123000100','student100@uniska.ac.id','mahasiswa',NULL,'active',1,'2026-07-17 16:40:13','2026-07-17 16:40:13'),(154,'Raendy','raendyelvicar','$2y$10$MaVfyi1r10ohT5xyhKzVVuHKONMswQN//evtEek3V/zX9lprauJQ6','Raendy','12212121','Laki-laki','Fakultas Teknologi Informasi','Sistem Informasi','081211111111','raendy.elvicar@gmail.com','mahasiswa',NULL,'active',39,'2026-07-18 04:32:17','2026-07-18 04:29:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'mental_health'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-18  7:13:40
